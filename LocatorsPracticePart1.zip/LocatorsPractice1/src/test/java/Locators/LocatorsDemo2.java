// className & TagName

package Locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatorsDemo2 
{

	public static void main(String[] args) 
	{
		// Launch Browser
		WebDriver driver=new ChromeDriver();
		
		//Open app or URL
		driver.get("http://www.automationpractice.pl/index.php");
		driver.manage().window().maximize(); //Open window in full screen
		
		//capture the sliders or multiple web elements 
		//Finding  number of sliders on the home page
		List<WebElement> sliders = driver.findElements(By.className("homeslider-container"));
		System.out.println("Number of sliders:" +sliders.size());
		
		//find total number of images in home page 
		List<WebElement> images = driver.findElements(By.tagName("img"));
		System.out.println("Number of images:" +images.size());
		
		//find total number of links 
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println("Total number of linkes:" +links.size());
		
		//Close browser
		driver.quit();
		
	}

}
